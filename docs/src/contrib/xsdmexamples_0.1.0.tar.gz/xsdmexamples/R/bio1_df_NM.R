#' @title bio1 time series
#' @description  We compute bio01 (Anual tas average) for a 30 years time series
#' centered in south New Mexico.   (xmin = -107, xmax = -104, ymin = 32, ymax = 35 )
#' @format A data frame with time series with 30 years of bio01 data
#' @details The data comes from chelsav2 time series.
"bio1_df_NM"
