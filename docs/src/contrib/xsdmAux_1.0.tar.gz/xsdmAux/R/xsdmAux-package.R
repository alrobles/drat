#' @useDynLib xsdmAux, .registration=TRUE
#' @import Rcpp
#' @importFrom RcppParallel RcppParallelLibs
"_PACKAGE"