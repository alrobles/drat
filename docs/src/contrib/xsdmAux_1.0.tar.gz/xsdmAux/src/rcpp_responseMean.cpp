#include <Rcpp.h>
#include <algorithm>
using namespace Rcpp;

#include <RcppParallel.h>
using namespace RcppParallel;

#include <cmath>
#include <vector>
#include <algorithm>

double response_function(const double x, const double param1, const double param2, const double param3)
{
  double u = x - param1;
  double v =  u < 0 ?  u/param2 : u/param3;
  double response = v * v;
  return response;
}

struct ResponseFunctor  {
  double param1;
  double param2;
  double param3;

  ResponseFunctor(double p1, double p2, double p3) : param1(p1), param2(p2), param3(p3) {}

  double operator()(double x) const {
    return response_function(x, param1, param2, param3);
  }
};

struct ResponseMean : public Worker {
  // input matrix to read from
  const RMatrix<double> mat;
  double par1;
  double par2;
  double par3;

  // output matrix to write to
  RMatrix<double> rmat;
  RMatrix<double> output;

  ResponseMean(const NumericMatrix mat,
               double p1,
               double p2,
               double p3,
               NumericMatrix rmat,
               NumericMatrix output
               )
    : mat(mat), par1(p1), par2(p2), par3(p3), rmat(rmat), output(output) {}

  void operator()(std::size_t begin, std::size_t end) {
    for (std::size_t i = begin; i < end; i++) {
      ResponseFunctor resFunctor(par1, par2, par3);

      RMatrix<double>::Row v1 = mat.row(i);
      RMatrix<double>::Row v2 = rmat.row(i);

      std::transform(v1.begin()  + begin,
                     v1.begin()  + end,
                     v2.begin()  + begin,
                     resFunctor);

      double result = std::accumulate(v2.begin(), v2.end(), 0.0)/v2.size();
      output(i, 0) = result;
    }
  }
};

// [[Rcpp::export]]
NumericMatrix rcpp_responseMean(NumericMatrix mat, double param1, double param2, double param3) {

  // allocate the matrix we will return,
  NumericMatrix rmat(mat.nrow(), mat.ncol());
  NumericMatrix output(mat.nrow(), 1);

  // create the worker
  ResponseMean responseMean(mat, param1, param2, param3, rmat, output);

  // call it with parallelFor
  parallelFor(0, mat.nrow(), responseMean);

  return output;
}
